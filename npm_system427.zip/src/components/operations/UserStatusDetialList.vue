<template>
	<div id="dox">
		用户实时状态
	</div>
	
</template>

<script>
	

</script>

<style>
</style>	