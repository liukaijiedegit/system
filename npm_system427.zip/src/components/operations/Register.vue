<template>
  <div class="mRight">
    <div class="mRightTwo">
      <div class="zForm">
        <span>服务器名称：</span><input class="zInput" type="text" placeholder="" /><button>查询</button><button>全部</button>
      </div>
      <div class="zTable">
        <div class="elTable">
        <el-table ref="multipleTable" :data="tableData3" tooltip-effect="dark" style="width: 100%">
          <el-table-column type="index" label="序号" width="90"></el-table-column>
          <el-table-column prop="uerId" label="区域" width="90"></el-table-column>
          <el-table-column prop="userImg" label="服务器名称" width="100"></el-table-column>
          <el-table-column prop="username" label="版本号" width="130"></el-table-column>
          <el-table-column prop="name" label="IP地址" width="130"></el-table-column>
          <el-table-column prop="phone" label="端口" width="122"></el-table-column>
          <el-table-column prop="userGroup" label="号码总数" width="100"></el-table-column>
          <el-table-column prop="device" label="号码使用量" width="130"></el-table-column>
          <el-table-column prop="media" label="在线用户" width="98"></el-table-column>
          <el-table-column prop="city" label="CPU" width="108"></el-table-column>
          <el-table-column prop="role" label="流量" width="108"></el-table-column>
          <el-table-column prop="YesNo" label="内存" width="108"></el-table-column>
          <el-table-column prop="police" label="线程" width="86"></el-table-column>
          <el-table-column label="添加日期" width="190">
            <template slot-scope="scope">{{ scope.row.date }}</template>
          </el-table-column>
        </el-table>
        </div>
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage4" :page-sizes="[100, 200, 300, 400]" :page-size="100" layout="total, sizes, prev, pager, next, jumper" :total="400">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
  import $ from 'jquery'
  export default {
    data() {
      return {
        tableData3: [{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        }, {
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        },{
          uerId: '北京市',
          userImg: '147',
          username: '3.26.3.0',
          name: '58.30.9.142',
          phone: '12310',
          userGroup: '2',
          device: '0.00%',
          media: '3',
          city: '5.00%',
          role: '37.00%',
          YesNo: '59.31%',
          police: '50',
          date: '2016/05/03 15:30:21',
        }],
        currentPage4: 4
      }
    },
    mounted: function() {
      var hei = document.documentElement.clientHeight;
      $('.mRightTwo').css('height', hei - 178);
      // $('tr td').addClass('tdaa')
    },
    methods: {
      toggleSelection(rows) {
        if(rows) {
          rows.forEach(row => {
            this.$refs.multipleTable.toggleRowSelection(row);
          });
        } else {
          this.$refs.multipleTable.clearSelection();
        }
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      }
    }
  }
</script>
<style>
  .mRightTwo {
    padding: 34px 42px;
    margin: 15px 27px 15px 15px;
    background: #354166;
    box-shadow: 0px 0px 26px #01060e;
  }

  .zForm {
    overflow: hidden;
    padding-bottom: 37px;
  }

  .zForm span {
    float: left;
    color: #eee;
    display: block;
    font-size: 16px;
    overflow: hidden;
    line-height: 36px;
  }

  .zTable {
    height: 94%;
    overflow: hidden;
  }
  
  .elTable {
    height: 88%;
    overflow: hidden;
  }
  .zInput {
    float: left;
    width: 120px;
    height: 36px;
    margin-left: 3px;
    line-height: 36px;
    padding-left: 14px;
    background: #1b274c;
    border: 1px #3b4872 solid;
  }

  .zForm button {
    float: left;
    color: #eee;
    width: 75px;
    height: 38px;
    font-size: 16px;
    margin-left: 11px;
    text-align: center;
    line-height: 38px;
    background: #1b274c;
    border: 1px #3b4872 solid;
  }

  .el-table,
  .el-table__expanded-cell,
  .el-table th,
  .el-table tr {
    background: none;
  }

  .el-table thead {
    font-size: 14px;
  }

  .el-table td,
  .el-table th.is-leaf {
    font-weight: normal;
    text-align: center;
  }

  .el-table_1_column_1 {
    border-radius: 6px 0 0 6px;
  }
  .el-table_1_column_14 {
    border-radius: 0 6px 6px 0;
  }

  .el-table .el-table__body-wrapper .el-table__row td {
    background: #4a567c;
  }

  .el-table td,
  .el-table th.is-leaf {
    border: none;
  }

  .el-table::before {
    height: 0px;
  }

  .el-checkbox__inner {
    background: none;
    border-color: #6c789f;
  }

  .el-table .cell {
    font-size: 14px;
  }

  .el-pagination {
    padding-top: 28px;
    text-align: right;
  }

  .el-pagination__total,
  .el-pagination__jump {
    color: #fff;
  }

  .el-pagination .btn-next,
  .el-pagination .btn-prev,
  .el-pager li,
  .el-pagination button:disabled {
    background: none;
  }

  .el-input__inner {
    color: #fff;
    background: #2a3558;
    border: 1px #3b4872 solid;
  }

  .el-select-dropdown {
    background: #2a3558;
    border: 1px #3b4872 solid;
  }

  .el-select-dropdown__item.hover,
  .el-select-dropdown__item:hover {
    background: #1b274c;
  }

  .el-popper[x-placement^=top] .popper__arrow::after {
    border-top-color: #2a3558;
  }

  .el-pagination__sizes .el-input .el-input__inner:hover,
  .el-input__inner:hover {
    border: 1px #3b4872 solid;
  }

  .el-table--enable-row-hover .el-table__body tr:hover>td{
    background: none;
  }
  .el-table--enable-row-hover .el-table__body tr:hover td {
    background: -webkit-linear-gradient(#3f7984, #485b7d, #3f7984);
    background: -o-linear-gradient(#3f7984, #485b7d, #3f7984);
    background: -moz-linear-gradient(#3f7984, #485b7d, #3f7984);
    background: linear-gradient(#3f7984, #485b7d, #3f7984);
    /*border: 1px #57e29b solid;*/
  }
</style>
