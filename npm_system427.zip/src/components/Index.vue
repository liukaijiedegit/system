<template>
	<div class="wrapper">
		<div class="head">
			<div class="user">
				<router-link to="/"><i class="iconfont icon-tuichu"></i>退出</router-link>
				<div class="userImg"><img src="../assets/userImg.jpg" /></div>
				<a href="javascript:;">admin</a>
			</div>
			<div class="indexlogo"><span><img src="../assets/logo.png"/></span>互联网接入平台</div>
		</div>
		<div class="main">
			<NavView></NavView>
		<!--	<HomeView></HomeView>-->
			 <router-view/>
		</div>
	</div>
	
</template>

<script>
	import NavView from '../components/Nav.vue'
	import $ from 'jquery'
	export default {
		components:{
		    NavView,	    
		},
		mounted () {
			// var h = $('.main').height();
			// $('.main').css('height',h+1)
		}
	}
</script>

<style>
.wrapper {
	height: 100%;
}
</style>