import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/Login'
import Index from '@/components/Index'
import NavView from '@/components/Nav'
import HomeView from '@/components/operations/Home'
import RegisterView from '@/components/operations/Register'
import TreeView from '@/components/organization/OrgStruckList'
import UserStatusView from '@/components/operations/UserStatusDetialList'

import UserListView from '@/components/user/UserList'

Vue.use(Router)

export default new Router({
	mode: 'history',
	routes: [{
		name: '',
		path: '',
		component: Login
	},

	{
		name: 'Index',
		path: '/Index',
		component: Index,
		children: [{
			name: '',
			path: '',
			component: HomeView
		},

		{
			name: 'Register',
			path: 'Register',
			component: RegisterView
		},
		{
			name: 'Tree',
			path: 'Tree',
			component: TreeView
		},

		{
			name: 'UserStatus',
			path: 'UserStatusDetialList',
			component: UserStatusView
		},
		{
			name: 'UserList',
			path: 'UserList',
			component: UserListView
		}

		]

	}

	]
})